#!/usr/bin/python

import threading
import time
import signal
import sys
import re
import getopt
import base64
import pycurl
from StringIO import StringIO

class pipper:
    def __init__(self,argv):
	self.urls=set()
	self.datas=set()
	self.hc=set()
	self.hc.add(0)
	self.hc.add(404)
	self.hl=set()
	self.num_threads=50
	self.threads = []
	self.method="HEAD"
	self.timeout=30
	self.username=""
	self.password=""
	self.argv=argv
	self.file=None
	self.data=None
	signal.signal(signal.SIGINT, self.sighandler)
	self.parseOptions()
	self.lock = threading.BoundedSemaphore(value=int(self.num_threads))
    def parseOptions(self):
	files={}
	if len(self.argv)<2 or self.argv[1]=="-h":
		self.help(self.argv[0])

	self.base=self.argv[1]
	print "URL         : %s" % self.base
   	try:
  		opts, args = getopt.getopt(self.argv[2:],"hf:t:d:u:p:",["file=","threads=","hc=","hl=","user=","pass=","username=","password=","data="])
   	except getopt.GetoptError,e:
		print "Error       :",e
      		self.help(self.argv[0])

	showHelp=False
   	for opt, arg in opts:
      		if opt=="--hc":
			self.hc.clear()
			if len(arg):
				for code in arg.split(","):
					self.hc.add(int(code))
      		if opt=="--hl":
			for lines in arg.split(","):
				self.hl.add(int(lines))
      		if opt in ("-d","--data"):
			self.data=arg
			self.method="POST"
      		if opt in ("-u","--user","--username"):
			self.username=arg
      		if opt in ("-p","--pass","--password"):
			self.password=arg
      		if opt == '-h':
         		showHelp=True
      		if opt in ("-f","--file"):
			self.file=arg
			try:
	        		with open(arg, "r") as f:
					files[arg]=f.read();
			except IOError,res:
				print res
				sys.exit()
		elif opt in ("-t","--threads"):
			self.num_threads=int(arg)

	if self.data!=None:
		print "Data        : %s" % self.data
	print "Method      : %s" % self.method
	print "Threads     : %s" % self.num_threads
	if len(self.hc):
		print "Hide code(s): %s" % ",".join(str(e) for e in self.hc)
	if len(self.hl):
		print "Hide #lines : %s" % ",".join(str(e) for e in self.hl)
	if len(self.username):
		print "Username    : %s" % self.username
	if len(self.password):
		print "Password    : %s" % self.password

	print "Timeout     : %d" % self.timeout

	if showHelp:
		self.help(self.argv[0])

	#url mutations
	if re.match(".*\[file\].*",self.base):
		if self.file==None:
			print "[Error] Provide a valid file with: -f <file>"
			sys.exit()
		print "File        : %s" % self.file
		for word in files[self.file].split("\n"):
			word=word.strip()
			if not len(word) or word[0]=='#':
				continue
			try:
				url=re.sub("\[file\]",self.raw_string(word),self.base)
				self.urls.add(url)
			except Exception,res:
				print "word '%s' -> %s" % (word,res)
				sys.exit()
	else:
		self.urls.add(self.base)

	#data mutations
	if self.data!=None:
		if re.match(".*\[file\].*",self.data):
			if self.file==None:
				print "[Error] Provide a valid file with: -f <file>"
				sys.exit()
			print "File        : %s" % self.file
			for word in files[self.file].split("\n"):
				word=word.strip()
				if not len(word) or word[0]=='#':
					continue
				try:
					data=re.sub("\[file\]",self.raw_string(word),self.data)
					self.datas.add(data)
				except Exception,res:
					print "word '%s' -> %s" % (word,res)
					sys.exit()
		else:
			self.datas.add(self.data)

	sys.stdout.write("Total Requ. : %s\n" % len(self.urls))
	sys.stdout.write("Total Datas : %s\n" % len(self.datas))
	sys.stdout.flush()

    def launch(self):
	#Donwload each URL
	id=1
	for url in self.urls:
		if len(self.datas):
			for data in self.datas:
				self.get(url,data,id)
				id+=1
		else:
			self.get(url,None,id)
			id+=1
	while threading.activeCount()>1:
		1
	print "\r\033[Kdone"

    def get(self,url,data,id):
        s=fetchHeaders(url,data,self.method,self.lock,self.hc,self.hl,self.timeout,id)
        s.start()
        self.threads.append(s)
    def raw_string(self,s):
    	if isinstance(s, str):
        	s = s.encode('string-escape')
    	elif isinstance(s, unicode):
        	s = s.encode('unicode-escape')
    	return s
    def sighandler(self,num, frame):
	for t in self.threads:
		t._Thread__stop()
	print "[^Canceled]\n"
	sys.exit()
    def help(self,app):
	print "Usage       : %s <url[+payloads]> [options]" % app
	print "Options     : -f   <file>    or --file <file> for payload [file]. Ex: %s http://server/[file] -f big.txt" % app
	print "              -d   <data>    POST data (ex: -d \"user=admin&pass=[file]\")"
	print "              -t   <threads> or --threads <num> (def. '%d')" % self.num_threads
	print "              --hc <code(s)> Hide responses with HTTP <code(s)> value (def. '%s')" % ",".join(str(e) for e in self.hc)
	print "              --hl <#lines>  Hide responses with HTTP lines (def. '%s')" % ",".join(str(e) for e in self.hl)
	sys.exit()

class fetchHeaders(threading.Thread):
    def __init__(self,url,data,method,lock,hc,hl,timeout,id):
	self.lock=lock
	self.url=url
	self.data=data
	self.method=method
	self.hc=hc
	self.hl=hl
	self.timeout=timeout
	self.id=id

	lock.acquire()

	#Initialize curl
	self.curl = pycurl.Curl()

	self.curl.setopt(self.curl.HEADER, 1)
	if self.method=="HEAD":
		self.curl.setopt(self.curl.NOBODY, 1) # header only, no body
	elif self.method=="POST":
		self.curl.setopt(self.curl.POSTFIELDS, data)
		self.curl.setopt(self.curl.NOBODY, 0)
		self.curl.setopt(self.curl.POST, 1)

	self.curl.setopt(pycurl.FOLLOWLOCATION, 0)
	self.curl.setopt(pycurl.SSL_VERIFYPEER, 0) 
	self.curl.setopt(pycurl.CONNECTTIMEOUT, self.timeout)
	self.curl.setopt(pycurl.NOSIGNAL, 1)
	self.curl.setopt(self.curl.URL, self.url)

	self.headers = StringIO()
	self.body = StringIO()

	self.curl.setopt(self.curl.HEADERFUNCTION, self.headers.write)
	self.curl.setopt(pycurl.WRITEFUNCTION, self.body.write)

	threading.Thread.__init__(self)

    def run(self):
	colors={"200":"\033[32;1m","301":"\033[36;1m","302":"\033[36;1m","303":"\033[36;1m","403":"\033[35;1m","404":"\033[31;1m","503":"\033[34;1m"}
	res=self.fetchUrl()

	if self.method=="HEAD":
		lines=len(res["headers"].split("\n"))
		words=len(res["headers"])
	else:
		lines=len(res["body"].split("\n"))
		words=len(res["body"])

	colored_code=str(res["code"])
	if colored_code in colors:
		colored_code=colors[str(colored_code)]+colored_code+"\033[0m"

	out="\r\033[K#%-5d|%3s|%4d|%5d|%-11s|" % (self.id,colored_code,lines,words,res["ctype"][:11])
	if not (res["code"] in self.hc) and not (lines in self.hl):
		out+=self.url
		if self.data!=None:
			out+=' -d "'+self.data+'"'
		if len(res["error"]):
			out+=" ("+res["error"]+")"
		if res["redir"]!=None:
			out+=" ("+res["redir"]+")"
		out+="\n"
	else:
		out+=self.url[:70]
		if self.data!=None:
			out+=' -d '+self.data[:30]
		if len(res["error"]):
			out+=" ("+res["error"]+")"
		if res["redir"]!=None:
			out+=" ("+res["redir"]+")"
	sys.stdout.write(out)
	sys.stdout.flush()

	self.lock.release()
	self._Thread__stop()

    def fetchUrl(self,redirections=False):
	msg_error=""
	content_type=""

	try:
		self.curl.perform()
		if self.headers.getvalue().lower().find("content-type:")!=-1:
			content_type=self.curl.getinfo(pycurl.CONTENT_TYPE)
		if content_type.find(";")!=-1:
			content_type=content_type.split(";")[0]
	except Exception,e:
		msg_error=e[1]

	return dict(body=self.body.getvalue(),headers=self.headers.getvalue(),code=self.curl.getinfo(pycurl.HTTP_CODE),ctype=content_type,redir=self.curl.getinfo(pycurl.REDIRECT_URL),error=msg_error)


if __name__ == "__main__":
	p=pipper(sys.argv)
	p.launch()
