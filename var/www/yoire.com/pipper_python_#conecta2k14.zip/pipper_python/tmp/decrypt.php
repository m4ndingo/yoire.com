#!/usr/bin/env php
<?php
function rc4Init($key)
{
  $hash      = array();
  $box       = array();
  $keyLength = strlen($key);
  
  for($x = 0; $x < 256; $x++)
  {
    $hash[$x] = ord($key[$x % $keyLength]);
    $box[$x]  = $x;
  }

  for($y = $x = 0; $x < 256; $x++)
  {
    $y       = ($y + $box[$x] + $hash[$x]) % 256;
    $tmp     = $box[$x];
    $box[$x] = $box[$y];
    $box[$y] = $tmp;
  }
  
  return $box;
}
function rc4(&$data, $key)
{
  $len = strlen($data);
  for($z = $y = $x = 0; $x < $len; $x++)
  {
    $z = ($z + 1) % 256;
    $y = ($y + $key[$z]) % 256;

    $tmp      = $key[$z];
    $key[$z]  = $key[$y];
    $key[$y]  = $tmp;
    $data[$x] = chr(ord($data[$x]) ^ ($key[(($key[$z] + $key[$y]) % 256)]));
  }
}

function visualDecrypt(&$data)

{

  $len = strlen($data);

  if($len > 0)for($i = $len - 1; $i > 0; $i--)$data[$i] = chr(ord($data[$i]) ^ ord($data[$i - 1]));

}

$key=rc4Init('78fghrYU%^&$ER');
$data=file_get_contents("config.bin");
rc4($data,$key);
visualDecrypt($data);
print $data;

