<?php
$a=file_get_contents("config.bin");
$b=file_get_contents("config.bin.1");

$ab="";
for($i=0;$i<strlen($a);$i++){
	$ab[$i]=chr(ord($a[$i])^ord($b[$i]));
}
for($i=0;$i<strlen($a);$i++){
	$_b[$i]=chr(ord($ab[$i])^ord($a[$i]));
}
for($i=0;$i<strlen($a);$i++){
	print chr(ord($_b[$i])^ord($b[$i]));
}
