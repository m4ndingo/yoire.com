curl -s http://cybercrime-tracker.net/|grep latest|cut -d: -f 3|cut -b3-|cut -d'"' -f 1 > cybercrime1.txt
curl -s http://cybercrime-tracker.net/all.php|sed "s/</\n/g"|cut -d'>' -f 2 > cybercrime_all.txt
