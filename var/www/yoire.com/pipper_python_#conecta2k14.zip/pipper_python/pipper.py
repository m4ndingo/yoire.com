#!/usr/bin/python

import threading
import time
import signal
import sys
import re
import getopt
import base64
import pycurl
from StringIO import StringIO
import hashlib
from bs4 import BeautifulSoup

class pipper:
    def __init__(self,argv):
	self.urls=[]
	self.datas=[]
	self.hc=set()
	self.hc.add(0)
	self.hc.add(404)
	self.hl=set()
	self.num_threads=50
	self.threads = []
	self.method="HEAD>GET"
	self.timeout=30
	self.username=""
	self.password=""
	self.argv=argv
	self.file=[]
	self.data=None
	self.encoder=None
	self.jump=0
	self.nocolors=False
	self.urlbase=False
	self.cancel=False
	self.parseOptions()
	self.lock = threading.BoundedSemaphore(value=int(self.num_threads))
	signal.signal(signal.SIGINT, self.sighandler)
    def parseOptions(self):
	files={}
	if len(self.argv)<2 or self.argv[1]=="-h":
		self.help(self.argv[0])

	self.base=self.argv[1]
	print "URL base    : %s" % self.base
   	try:
  		opts, args = getopt.getopt(self.argv[2:],"hf:t:d:j:u:m:p:n",["file=","threads=","hc=","hl=","user=","pass=","username=","password=","data=","md5","jump=","method=","nocolors","urlbase"])
   	except getopt.GetoptError,e:
		print "Error       :",e
      		self.help(self.argv[0])

	showHelp=False
   	for opt, arg in opts:
      		if opt=="--hc":
			self.hc.clear()
			if len(arg):
				for code in arg.split(","):
					self.hc.add(int(code))
      		if opt=="--hl":
			for lines in arg.split(","):
				self.hl.add(int(lines))
      		if opt=="-n" or opt=="--nocolors":
			self.nocolors=True
      		if opt=="--urlbase":
			self.urlbase=True
      		if opt in ("-d","--data"):
			self.data=arg
			self.method="POST"
		if opt=="--md5":
			self.encoder="md5"
		if opt in ("--method","-m"):
			self.method=arg
      		if opt in ("-u","--user","--username"):
			self.username=arg
      		if opt in ("-p","--pass","--password"):
			self.password=arg
      		if opt in ("-j","--jump"):
			self.jump=int(arg)
      		if opt == '-h':
         		showHelp=True
      		if opt in ("-f","--file"):
			print "File(%d)     : %s" % (len(self.file),arg)
			self.file.append(arg)
			try:
	        		with open(arg, "r") as f:
					files[arg]=f.read();
			except IOError,res:
				print res
				sys.exit()
		elif opt in ("-t","--threads"):
			self.num_threads=int(arg)

	if self.data!=None:
		print "Data        : %s" % self.data
	print "Method      : %s" % self.method
	print "Threads     : %s" % self.num_threads
	if len(self.hc):
		print "Hide code(s): %s" % ",".join(str(e) for e in self.hc)
	if len(self.hl):
		print "Hide #lines : %s" % ",".join(str(e) for e in self.hl)
	if len(self.username):
		print "Username    : %s" % self.username
	if len(self.password):
		print "Password    : %s" % self.password

	print "Timeout     : %d" % self.timeout

	if showHelp:
		self.help(self.argv[0])

	#url mutations
	if re.match(".*\[file\].*",self.base):
		if not len(self.file):
			print "[Error] Provide a valid file with: -f <file>"
			sys.exit()
		for word in files[self.file[0]].split("\n"):
			word=word.replace("\r","")
			word=word.strip()
			if self.urlbase:
				lastpos=word.rfind("/")
				if lastpos!=-1 and lastpos>8:
					word=word[:lastpos+1]
			if not len(word) or word[0]=='#':
				continue
			try:
				#word=self.raw_string(word)
				if self.encoder=="md5":
					word= hashlib.md5(word).hexdigest()
				url=re.sub("\[file\]",word,self.base)
				self.urls.append(dict(url=url,word=word))
			except Exception,res:
				print "word '%s' -> %s" % (word,res)
				sys.exit()
	else:
		self.urls.append(dict(url=self.base,word=""))

	#data mutations
	filenum=0
	if self.data!=None:
		if re.match(".*\[file\].*",self.data):
			if not len(self.file):
				print "[Error] Provide a valid file with: -f <file>"
				sys.exit()
			if len(self.file)>1:	#more than one file? the second is for datas...
				filenum+=1
			print "File        : %s" % self.file[filenum]
			for word in files[self.file[filenum]].split("\n"):
				word=word.replace("\r","")
				word=word.strip()
				if not len(word) or word[0]=='#':
					continue
				try:
					#word=self.raw_string(word)
					if self.encoder=="md5":
						word=hashlib.md5(word).hexdigest()
					data=re.sub("\[file\]",word,self.data)
					self.datas.append(dict(data=data,word=word))
				except Exception,res:
					print "word '%s' -> %s" % (word,res)
					sys.exit()
		else:
			self.datas.append(dict(data=self.data,word=""))

	sys.stdout.write("Total URLs  : %s\n" % len(self.urls))
	sys.stdout.write("Total Datas : %s\n" % len(self.datas))
	if self.jump>0:
		sys.stdout.write("Jump#       : %d\n" % self.jump)
	sys.stdout.flush()

    def launch(self):
	#Donwload each URL
	id=1
	for url in self.urls:
		if self.cancel:
			break		
		if len(self.datas):
			for data in self.datas:
				if id-self.jump>0:
					self.get(url["url"],data["data"],id)
				id+=1
		else:
			if id-self.jump>0:
				self.get(url["url"],None,id)
			id+=1
	while threading.activeCount()>1:
		1
	print "\r\033[Kdone"

    def get(self,url,data,id):
        s=fetchHeaders(url,data,self.method,self.lock,self.hc,self.hl,self.timeout,self.nocolors,id)
        s.start()
        self.threads.append(s)
    def raw_string(self,s):
    	if isinstance(s, str):
        	s = s.encode('string-escape')
    	elif isinstance(s, unicode):
        	s = s.encode('unicode-escape')
    	return s
    def sighandler(self,num, frame):
	self.cancel=True
	for t in self.threads:
		t._Thread__stop()
	print "[^Canceled]\n"
	sys.exit()
    def help(self,app):
	print "Usage       : %s <url[+payloads]> [options]" % app
	print "Options     : -f   <file>    or --file <file> for payload [file]. Ex: %s http://server/[file] -f big.txt" % app
	print "              -d   <data>    POST data (ex: -d \"user=admin&pass=[file]\")"
	print "              -t   <threads> or --threads <num> (def. '%d')" % self.num_threads
	print "              --hc <code(s)> Hide responses with HTTP <code(s)> value (def. '%s')" % ",".join(str(e) for e in self.hc)
	print "              --hl <#lines>  Hide responses with HTTP lines (def. '%s')" % ",".join(str(e) for e in self.hl)
	print "              --md5          Generate MD5 digest of each payload"
	print "              -j   <#paynum> or --jump <num> to jump into payload #"
	print "              -m   <method>  or --method <method> Available methods: HEAD, GET, POST, HEAD>GET"
	print "              -nc            or --nocolors for uncolored output"
	print "              --urlbase      remove the script names from the URLs/paths readed from files"
	sys.exit()

class fetchHeaders(threading.Thread):
    def __init__(self,url,data,method,lock,hc,hl,timeout,nocolors,id):
	self.lock=lock
	self.url=url
	self.data=data
	self.method=method
	self.hc=hc
	self.hl=hl
	self.timeout=timeout
	self.nocolors=nocolors
	self.id=id

	self.donotend=False

	lock.acquire()

	#Initialize curl
	self.curl = pycurl.Curl()

	self.curl.setopt(self.curl.HEADER, 1)
	if self.method=="HEAD":
		self.curl.setopt(self.curl.NOBODY, 1) # header only, no body
	elif self.method=="POST":
		self.curl.setopt(self.curl.POSTFIELDS, data)
		self.curl.setopt(self.curl.NOBODY, 0)
		self.curl.setopt(self.curl.POST, 1)

	self.curl.setopt(pycurl.FOLLOWLOCATION, 0)
	self.curl.setopt(pycurl.SSL_VERIFYPEER, 0) 
	self.curl.setopt(pycurl.CONNECTTIMEOUT, self.timeout)
	self.curl.setopt(pycurl.NOSIGNAL, 1)
	self.curl.setopt(self.curl.URL, self.url)

	threading.Thread.__init__(self)

    def run(self):
	colors={}
	if not self.nocolors:
		colors={"200":"\033[32;1m","301":"\033[36;1m","302":"\033[36;1m","303":"\033[36;1m","403":"\033[35;1m","404":"\033[31;1m","502":"\033[34;1m","503":"\033[34;1m","504":"\033[34;1m","508":"\033[34;1m","500":"\033[34;1m",
		"application/octet-stream":"\033[33;1m"}

	self.headers = StringIO()
	self.body = StringIO()

	self.curl.setopt(self.curl.HEADERFUNCTION, self.headers.write)
	self.curl.setopt(pycurl.WRITEFUNCTION, self.body.write)

	res=self.fetchUrl()	#CURL NOW

	title=None

	if self.method=="HEAD" or self.method=="HEAD>GET":
		lines=len(res["headers"].split("\n"))
		words=len(res["headers"])
	else:
		lines=len(res["body"].split("\n"))
		words=len(res["body"])
		try:
			b=BeautifulSoup(res["body"])
			if b.find("title")!=None:
				title=b.find("title").text.strip()
		except Exception:
			1
	colored_code=str(res["code"])
	color_code=""
	if not self.nocolors:
		color_code="\033[0m"
	if colored_code in colors:
		colored_code=colors[str(colored_code)]+colored_code+"\033[0m"
		color_code=colors[str(res["code"])]
	colored_type=res["ctype"][:9]
	if res["ctype"] in colors:
		colored_type=colors[res["ctype"]]+colored_type+"\033[0m"

	out="\r\033[K#%-5d|%-8s|%3s|%4d|%5d|%-8s|" % (self.id,self.method,colored_code,lines,words,colored_type)
	if not (res["code"] in self.hc) and not (lines in self.hl):
		out+=self.url
		if self.data!=None:
			out+=' -d "'+self.data+'"'
		if len(res["error"]):
			out+=" ("+res["error"]+")"
		if res["redir"]!=None:
			out+=" ("+res["redir"]+")"
		if title!=None:
			out+=color_code+" # "+title[:50]
			if not self.nocolors:
				out+="\033[0m"
			if len(title)>50:
				out+="..."
		out+="\n"
	else:
		out+=self.url[:70]
		if len(self.url)>70:
			out+="..."
		if self.data!=None:
			out+=' -d '+self.data[:30]
			if len(self.data)>30:
				out+="..."
		if len(res["error"]):
			out+=" ("+res["error"]+")"
		if res["redir"]!=None:
			out+=" ("+res["redir"]+")"
		if title!=None:
			out+=color_code+" # "+title[:10]
			if not self.nocolors:
				out+="\033[0m"

	try:
		sys.stdout.write(out)
	except Exception:
		1
	sys.stdout.flush()

	self.log(out)

	if self.method=="HEAD" or self.method=="HEAD>GET":
		self.log(res["headers"])
	else:
		self.log(res["body"])

        if self.method=="HEAD>GET" and res["code"]!=404 and res["code"]!=403:
		self.method="GET"
		urltmp=self.url
		if res["redir"]!=None:
			self.url=res["redir"]
			self.curl.setopt(self.curl.URL, res["redir"])
		self.donotend=True
		self.run()

	if self.donotend:
		self.donotend=False
		return

	self.lock.release()
	self._Thread__stop()
    def fetchUrl(self,redirections=False):
	msg_error=""
	content_type="---------"

	try:
		self.curl.perform()
		if self.headers.getvalue().lower().find("content-type:")!=-1:
			content_type=self.curl.getinfo(pycurl.CONTENT_TYPE)
		if content_type.find(";")!=-1:
			content_type=content_type.split(";")[0]
	except Exception,e:
		msg_error=e[1]

	return dict(body=self.body.getvalue(),headers=self.headers.getvalue(),code=self.curl.getinfo(pycurl.HTTP_CODE),ctype=content_type,redir=self.curl.getinfo(pycurl.REDIRECT_URL),error=msg_error)

    def log(self,data):
	with open("logs.pipper", "a") as myfile:
		try:
	    		myfile.write(data)
		except Exception:
			1
	myfile.close()

if __name__ == "__main__":
	p=pipper(sys.argv)
	p.launch()
