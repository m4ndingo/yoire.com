#!/usr/bin/env bash
curl -s https://zeustracker.abuse.ch/monitor.php?browse=binaries |grep 'C">'|cut -d '>' -f 6|cut -d'<' -f 1 > zeus_binary_urls.txt
