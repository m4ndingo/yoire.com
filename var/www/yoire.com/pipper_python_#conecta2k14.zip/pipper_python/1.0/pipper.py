#!/usr/bin/python

import threading
import urllib2
import time
import signal
import sys
import re
import getopt
import base64

cancel=False

class pipper:
    def __init__(self,argv):
	global cancel
	self.urls=set()
	self.num_threads=10
	self.hc=404
	self.threads = []
	self.method="HEAD"
	self.argv=argv
	cancel=False
	signal.signal(signal.SIGINT, self.sighandler)
	self.parseOptions()
	self.lock = threading.BoundedSemaphore(value=int(self.num_threads))
    def parseOptions(self):
	global cancel
	files={}
	if len(self.argv)<2:
		self.help(self.argv[0])

	self.base=self.argv[1]
	print "URL    : %s" % self.base
	print "Method : %s" % self.method
   	try:
  		opts, args = getopt.getopt(self.argv[2:],"hf:t:",["file=","threads="])
   	except getopt.GetoptError:
      		self.help(self.argv[0])
   	for opt, arg in opts:
      		if opt == '-h':
         		self.help(self.argv[0])
      		elif opt in ("-f","--file"):
			self.file=arg
			try:
	        		with open(arg, "r") as f:
					files[arg]=f.read();
			except IOError,res:
				print res
				sys.exit()
		elif opt in ("-t","--threads"):
			self.num_threads=int(arg)

	print "Threads: %s" % self.num_threads

	if re.match(".*\[file\].*",self.base):
		print "File   : %s" % self.file
		for word in files[self.file].split("\n"):
			word=word.strip()
			if not len(word) or word[0]=='#':
				continue
			try:
				url=re.sub("\[file\]",self.raw_string(word),self.base)
				self.urls.add(url)
			except Exception,res:
				print "word '%s' -> %s" % (word,res)
				sys.exit()
		sys.stdout.write("Built  : %s URLs\n" % len(self.urls))
		sys.stdout.flush()
	else:
		self.urls.add(self.base)

    def launch(self):
	#Donwload the URLs
	id=1
	for url in self.urls:
		if cancel:
			sys.exit()	
		self.get(url,id)
		id+=1
	if not cancel:
		while threading.activeCount()>1:
			1
	print "\r\033[Kdone"

    def get(self,url,id):
	global cancel
	if cancel:
		print "canceled"
		sys.exit()
	self.lock.acquire()
        s=fetchHeaders(url,self.method,self.lock,self.hc,id)
        s.start()
        self.threads.append(s)
    def help(self,app):
	print "Usage: %s <url>" % app
	sys.exit()
    def raw_string(self,s):
    	if isinstance(s, str):
        	s = s.encode('string-escape')
    	elif isinstance(s, unicode):
        	s = s.encode('unicode-escape')
    	return s
    def sighandler(self,num, frame):
	global cancel
  	cancel = True
	print "\n"

class fetchHeaders(threading.Thread):
    def __init__(self,url,method,lock,hc,id):
	threading.Thread.__init__(self)
	self.lock=lock
	self.url=url
	self.method=method
	self.hc=hc
	self.id=id
    def run(self):
	global cancel
	if cancel:
		return
	res=self.fetchUrl()
	line=0
	if self.method=="HEAD":
		lines=len(res["info"])
		words=len(str(res["info"]))
	out="\r\033[K#%-5d|%3d|%4d|%5d|" % (self.id,res["code"],lines,words)
	if res["code"]!=self.hc:
		out+=self.url+"\n"
	else:
		out+=self.url[:80]
	sys.stdout.write(out)
	sys.stdout.flush()

    def fetchUrl(self,redirections=False):
	global cancel
    	opener = urllib2.OpenerDirector()
	opener.add_handler(urllib2.HTTPHandler())
    	opener.add_handler(urllib2.HTTPDefaultErrorHandler())
	if self.url.find("https://")!=-1:
    		opener.add_handler(urllib2.HTTPSHandler())
	if redirections:
        	opener.add_handler(urllib2.HTTPErrorProcessor())
        	opener.add_handler(urllib2.HTTPRedirectHandler())
    	try:
        	res = opener.open(HeadRequest(self.url))
    	except urllib2.HTTPError, e:
        	pass
	except (ValueError, urllib2.URLError), e:
		cancel=True
		print "\rERROR",e
		self.lock.release()
		sys.exit()
    	res.close()
	self.lock.release()
	return dict(info=res.info(),code=res.code)

class HeadRequest(urllib2.Request):
    def get_method(self):
        return 'HEAD'

if __name__ == "__main__":
	p=pipper(sys.argv)
	p.launch()
